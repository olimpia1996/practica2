def fuerza(m: float, a:float)-> float:
    f = m * a
    return  f


def presion(f: float, s:float)-> float:
    p = f / s
    return p