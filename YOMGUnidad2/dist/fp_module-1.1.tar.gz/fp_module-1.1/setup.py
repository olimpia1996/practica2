from setuptools import setup

setup(
    name='fp_module',
    version='1.1',
    description='The equations example Application Programming',
    author='YOMG',
    author_email='yanemora1996@gmail.com',
    url='trello.com/pa',
    py_modules=['fp_module'],
)
